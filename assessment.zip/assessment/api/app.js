var bodyparser = require('body-parser');
var express = require('express');
var promise = require('bluebird');
var app = express();


var options = { promiseLib :promise}

 var dt = require('pg-promise')(options);
 var cs = 'postgres:postgres:root1@localhost:5432/trans';

 var db = dt(cs);

 app.set('port', process.env.PORT || 4600);

//  app.all('*', function (req, res, next) {

//     res.header("Access-Control-Allow-Origin", '*');

//     res.header("Access-Control-Allow-Headers", "Cache-Control,Pragma, Origin, Authorization, Content-Type, X-Requested-With");

//     res.header("Access-Control-Allow-Methods", "*");

//     return next();
// });
app.use(bodyparser.urlencoded({ limit: "50mb", extended:true}));
app.use(bodyparser.json({ limit: "100mb"}));




app.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');


    res.setHeader('Access-Control-Allow-Methods', '*');


    res.setHeader('Access-Control-Allow-Headers', '*');


    res.setHeader('Access-Control-Allow-Credentials', true);


    next();
});




 


 app.get('/',(req,res)=>{
     res.send ('Database connected');
 })

 app.get('/login/:username/:password',(req,res,next)=>{
 var u=req.params.username
 var p=req.params.password
console.log(req.params)
 db.any('select * from signup where userid =$1 and password = $2',[u,p]).then(data=>{

    res.send(data)
 })

 })

 app.get('/speech/:userid',(req,res,next)=>{
var w=req.params.userid
db.any('select * from speech where userid=$1',[w]).then(data=>{

    res.send(data)
})

 })

 app.get('/allspeeches',(req,res,next)=>{

    db.any('select * from speech').then(data=>{
        res.send(data)
    })
 })

 app.get('/speechbyid/:id',(req,res,next)=>{
var id = req.params.id;
    db.any('select * from speech where speechid = $1',[id]).then(data=>{
        res.send(data)
    })
 })

 app.post('/signup',(req,res,next)=>{
     console.log(req.body);

var id=req.body.userid
var email=req.body.emailid
var password=req.body.password

db.any('insert into signup(userid,emailid,password) values($1,$2,$3)',[id,email,password]).then(data=>{

    res.send({'message':'registration successfull'})
})

 })

 app.post('/speech/:id',(req,res,next)=>{


var uid=req.params.id;
var s=req.body.speech
var a=req.body.author
var sa=req.body.keyword;
var d=req.body.date

db.any('insert into speech(userid,speech,author,subjectaarea,sdate) values($1,$2,$3,$4,$5)',[uid,s,a,sa,d]).then(data=>{
 res.send({'message':'speech inserted'})

})

 })


 app.put('/speechupdate',(req,res,next)=>{


    console.log(req.body);
    var s=req.body.speech
    var a=req.body.author
    var sa=req.body.keyword;
    var d=req.body.date
    var speechid = req.body.speechid;
    
    db.any('update speech set speech=$1,author=$2,subjectaarea=$3,sdate=$4 where speechid =$5',[s,a,sa,d,speechid]).then(data=>{
     res.send({'message':'speech inserted'})
    
    })
    
     })

     app.delete('/deletespeech/:id',(req,res,next)=>{
         var id = req.params.id;

        db.any('delete from speech where speechid=$1',[id]).then(data=>{
          res.send({'message':'delete sucessfully'});
        })
     })
    





 app.listen(app.get('port'),(err=>{
     if(err)
     console.log('serve not started')
     else
     console.log('server started at : http://localhost:4600 ');
 }))
