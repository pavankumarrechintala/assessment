import { Component, OnInit } from '@angular/core';
import { speech } from '../model/model';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
speech:any;
userid:any;
  constructor(private service:TaskService,private router:Router) { }
  submit(frm){
  
   this.userid= localStorage.getItem('userid');

    this.service.submitspeech(frm, this.userid).subscribe(data=>{
   this.router.navigate(['viewspeech'])
    })
 
  }
  ngOnInit() {
  }

}
