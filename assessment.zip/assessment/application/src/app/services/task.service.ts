import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient,HttpHeaders} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class TaskService {

url:string = 'http://localhost:4600/';


  constructor(private http:HttpClient ) {
    
   }

  loginserv(id:any,password:any):Observable<any>{
return this.http.get(this.url+ 'login/'+id+'/'+password ,{responseType:'json'})
  }

  registerserv(frm) : Observable<any>{  
 
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.http.post(this.url+'signup',frm,httpOptions)


  }

myspeeches(userid) :Observable<any>{
  return this.http.get(this.url+'speech/'+userid,{responseType : 'json'})
}

allspeeches() : Observable<any>{
  return this.http.get(this.url+'allspeeches',{responseType :'json'})
}

submitspeech(frm,id) :Observable<any>{
  const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  
  }
  return this.http.post(this.url+'speech/'+id,frm,httpOptions)
}

speechbyid(id):Observable<any>{
  return this.http.get(this.url+'speechbyid/'+id,{responseType:'json'});
}
updatespeech(frm):Observable<any>{
  const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  
  }
  return this.http.put(this.url + 'speechupdate',frm,httpOptions);
}
deletespeech(id):Observable<any>{
return  this.http.delete(this.url+'deletespeech/'+id)
}









}
