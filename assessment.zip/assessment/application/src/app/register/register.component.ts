import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {TaskService} from '../services/task.service'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  register: any = []
  constructor(private router:Router,private service:TaskService) { }


  btnclk(regfrm) {
   
   
  
    console.log( regfrm)
   this.service.registerserv(regfrm).subscribe(data=>{
this.router.navigate(['login'])
    })

    }
    



  


  ngOnInit() {
  }

}
