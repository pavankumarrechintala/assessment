import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewspeechsComponent } from './viewspeechs.component';

describe('ViewspeechsComponent', () => {
  let component: ViewspeechsComponent;
  let fixture: ComponentFixture<ViewspeechsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewspeechsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewspeechsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
