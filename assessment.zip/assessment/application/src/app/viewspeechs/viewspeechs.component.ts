import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task.service';
import { speech } from '../model/model';

@Component({
  selector: 'app-viewspeechs',
  templateUrl: './viewspeechs.component.html',
  styleUrls: ['./viewspeechs.component.css']
})
export class ViewspeechsComponent implements OnInit {
speech:speech;
speech1:any;
  constructor(private service:TaskService) { 
    this.speech1 = new speech();
  }



  speechget(id){
  
    this.service.speechbyid(id).subscribe(data=>{
this.speech1 = data[0];
console.log(this.speech1);
    })
  }
  delete(id){
this.service.deletespeech(id).subscribe(data=>{
  this.ngOnInit();
  this.speech1='';
  
})
  }
  save(frm){
    
    console.log(frm);
    this.service.updatespeech(frm).subscribe(data=>{

    })
  }
  ngOnInit() {
    var userid = localStorage.getItem("userid")
this.service.myspeeches(userid).subscribe(data=>{
  this.speech = data
  console.log(this.speech);
})
  }

}
