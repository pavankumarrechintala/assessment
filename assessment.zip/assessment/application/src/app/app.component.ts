import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { of, Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'trans';

  lgval: Observable<string>
  constructor(private rt:Router) {
  }

  private CheckLocalStore(): Observable<any> {
    return of(localStorage.getItem("userid"));
}


logOutClick()
{
    localStorage.removeItem("userid")
    this.rt.navigate(['login'])
}
  
  ngDoCheck() {
    this.CheckLocalStore().subscribe((data) => { this.lgval = data })
}
}
