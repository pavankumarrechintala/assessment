import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router : Router,private service : TaskService) { }



  btnloginClick(u,p){
    // console.log(u+p)
this.service.loginserv(u,p).subscribe((data) => {

if (data.length > 0) {
localStorage.setItem("userid",u)

this.router.navigate(['dashboard'])
}
else{
alert('invalid credintials')
}
})





}


register(){
  this.router.navigate(['register']);
}
  ngOnInit() {
  }

}
