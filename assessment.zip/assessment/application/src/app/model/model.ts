export class speech{
    speechid:any;
    userid:any;
    speech:any;
    author:any;
    subjectaarea:any;
    sdate:Date;
}