import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-allspeechs',
  templateUrl: './allspeechs.component.html',
  styleUrls: ['./allspeechs.component.css']
})
export class AllspeechsComponent implements OnInit {
speech:any;
  constructor(private service:TaskService) { }

  ngOnInit() {
this.service.allspeeches().subscribe(data=>{
this.speech=data;
console.log(this.speech);
})
  }

}
