import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllspeechsComponent } from './allspeechs.component';

describe('AllspeechsComponent', () => {
  let component: AllspeechsComponent;
  let fixture: ComponentFixture<AllspeechsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllspeechsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllspeechsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
