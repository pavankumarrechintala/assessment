Software Used:

Database   : pgplsql
FrontEnd   : Angular7
BackEnd    : Node.js10
Typescript : 3.3.1
middleware : Expressjs

Database Requirements/Procedures :

Table         :1) signup
              :2) speech

Angular FrontEnd :

Step1: Need to install "nodemodules" --npm install
Step2: To run the application use command  --npm start/ng serve

Prerequisites :

Before you begin, make sure your development environment includes Node.js and an npm package Manager

Nodejs Backend :

  **Uploaded file including "nodemodules" **
  **Main application is available in a file named as "app.js"

Step1:Run the server/api using command --node app.js.


Flow of application :
 1) You need to register and then you can able to login and use the page.
 Example:Included Credentials : UserId   : pavan
                        password : 1234

 2) You can able to act on three buttons Accordingly.(View my speeches/Submit a speech/Search all speeches)

